Postgrex.Types.define(Postgrex.DefaultTypes, [],
  moduledoc: """
  The default module used to encode/decode PostgreSQL types.

  Type modules are given as the `:types` option in `Postgrex.start_link/1`.
  """
)
