[
  inputs: ["mix.exs", "{lib,test}/**/*.{ex,exs}"],
]
